document.getElementById('send-button').addEventListener('click', sendMessage);
document.getElementById('voice-button').addEventListener('click', startVoiceInput);
window.onload = () => document.getElementById('bg-music').play();

function sendMessage() {
  const input = document.getElementById('user-input');
  const message = input.value.trim();
  if (!message) return;

  const chatBox = document.getElementById('chat-box');
  const userBubble = document.createElement('div');
  userBubble.className = 'user-message';
  userBubble.textContent = message;
  chatBox.appendChild(userBubble);
  input.value = '';

  fetch('/ask', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message })
  })
  .then(res => res.json())
  .then(data => {
    const botBubble = document.createElement('div');
    botBubble.className = 'bot-message';
    botBubble.textContent = data.response;
    chatBox.appendChild(botBubble);
    chatBox.scrollTop = chatBox.scrollHeight;
    speak(data.response);
  })
  .catch(() => {
    const errorBubble = document.createElement('div');
    errorBubble.className = 'error-message';
    errorBubble.textContent = 'Error: Unable to connect to server.';
    chatBox.appendChild(errorBubble);
  });
}

function speak(text) {
  const speech = new SpeechSynthesisUtterance(text);
  speech.lang = 'en-US';
  speech.pitch = 1.2;
  speech.rate = 0.9;
  speech.voice = window.speechSynthesis.getVoices().find(v => v.name.includes('Google') || v.name.includes('Arjun'));
  window.speechSynthesis.speak(speech);
}

function startVoiceInput() {
  if (!('webkitSpeechRecognition' in window)) {
    alert('Speech recognition not supported in this browser.');
    return;
  }
  const recognition = new webkitSpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US';
  recognition.start();
  recognition.onresult = function(event) {
    const transcript = event.results[0][0].transcript;
    document.getElementById('user-input').value = transcript;
    sendMessage();
  };
  recognition.onerror = function(event) {
    alert('Voice input error: ' + event.error);
  };
}