
document.getElementById('send-button').addEventListener('click', sendMessage);
document.getElementById('voice-button').addEventListener('click', startVoiceInput);

function sendMessage() {
  const input = document.getElementById('user-input');
  const message = input.value.trim();
  if (!message) return;

  const chatBox = document.getElementById('chat-box');
  const userBubble = document.createElement('div');
  userBubble.className = 'user-message';
  userBubble.textContent = message;
  chatBox.appendChild(userBubble);
  input.value = '';

  fetch('/ask', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message })
  })
  .then(res => res.json())
  .then(data => {
    const botBubble = document.createElement('div');
    botBubble.className = 'bot-message';
    botBubble.textContent = data.response;
    chatBox.appendChild(botBubble);
    chatBox.scrollTop = chatBox.scrollHeight;
    speak(data.response);
  });
}

function startVoiceInput() {
  const recognition = new webkitSpeechRecognition();
  recognition.lang = 'en-US';
  recognition.onresult = function(event) {
    document.getElementById('user-input').value = event.results[0][0].transcript;
    sendMessage();
  };
  recognition.start();
}

function speak(text) {
  const speech = new SpeechSynthesisUtterance(text);
  speech.lang = 'en-IN';
  speech.pitch = 1;
  speech.rate = 1;
  speech.volume = 1;
  speechSynthesis.speak(speech);
}
